<!DOCTYPE html>
<html>
<head>
    <title>Addition and Subtraction</title>
</head>
<body>
    <h1>Addition and Subtraction</h1>
    <form action="calculate.php" method="post">
        <label for="num1">Number 1:</label>
        <input type="number" id="num1" name="num1" required><br>

        <label for="num2">Number 2:</label>
        <input type="number" id="num2" name="num2" required><br>

        <input type="submit" value="Calculate">
    </form>
</body>
</html>
